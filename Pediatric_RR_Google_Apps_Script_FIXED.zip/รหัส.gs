function doGet() {
  return HtmlService
    .createHtmlOutputFromFile('Index')
    .setTitle('Pediatric RR Camera Counter')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover');
}
